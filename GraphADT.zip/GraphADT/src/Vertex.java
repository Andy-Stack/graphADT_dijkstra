import java.util.HashMap;
import java.util.Map;

public class Vertex {

    private final int key;
    private final Map<Integer, Map<String, Integer>> connectedTo;
    private final String nl = System.lineSeparator();
    private Integer weightFromSource;

    /**
     * Constructor requires vertex key.
     * @param key - the key that will be associated with the vertex object.
     */
    public Vertex(int key) {
        this.key = key;
        connectedTo = new HashMap<>();
        weightFromSource = Integer.MAX_VALUE;
    }

    public int getKey() {
        return key;
    }

    public Integer getWeightFromSource() {
        return weightFromSource;
    }

    public void setWeightFromSource(Integer weightFromSource) {
        this.weightFromSource = weightFromSource < 0 ? 0 : weightFromSource;
    }

    /**
     * getter method for vertex connections.
     * (Nested maps contain weight and accessible status)
     * @return Map who's keys are vertex keys and values are maps.
     */
    public Map<Integer, Map<String, Integer>> getConnections() {
        return connectedTo;
    }

    /**
     * Prints information about the vertex (neighbour) based on key parameter.
     * Prints key, weight (from source to neighbour), accessible status.
     * @param key a vertex key.
     */
    public void printConnection(int key) {
        if (getConnections().containsKey(key)) {
            Map<String, Integer> neighbour = getConnections().get(key);
            System.out.print("Vertex: " + key);
            System.out.print(" Weight: " + neighbour.get("weight"));
            System.out.print(" Accessible: " + new String[]{"No", "Yes"}[neighbour.get("accessible")] + nl);
        } else {
            System.out.println("Connection not found");
        }
    }

    /**
     * Prints the keys of all neighbouring vertices.
     */
    public void printConnections() {
        System.out.println("Vertex " + getKey() + " connections:");
        if (getConnections().isEmpty()) {
            System.out.println("No connections");
        } else {
            for (int key : getConnections().keySet()) {
                printConnection(key);
            }
        }
    }

    /**
     * removes vertex from map of connected vertices (removal of graph edge).
     * @param key a vertex key.
     * @return True if vertex was found and removed, false otherwise.
     */
    public boolean deleteEdge(int key) {
        Map<Integer, Map<String, Integer>> connections = getConnections();
        if (connections.containsKey(key)) {
            connections.remove(key);
            return true;
        }
        return false;
    }

    /**
     * Adds a vertex key to map of neighbours, assumes that the key represents an existing vertex.
     * @param key a vertex key.
     * @return True if vertex was added as neighbour, false if already a neighbour.
     */
    public boolean addNeighbour(int key) {
        Map<Integer, Map<String, Integer>> connections = getConnections();
        if (connections.containsKey(key)) {
            System.out.println("Vertex already a neighbour");
            return false;
        }
        Map<String, Integer> connection = new HashMap<>();
        connection.put("weight", 0);
        connection.put("accessible", 1);
        connections.put(key, connection);
        return true;
    }

    /**
     * Adds a vertex key to map of neighbours, assumes that the key represents an existing vertex.
     * Assigns weight to the added vertex from weight parameter.
     * @param key a vertex key.
     * @param weight an integer number to represent the weight of an edge.
     * @return True if vertex was added as neighbour, false if already a neighbour.
     */
    public boolean addNeighbour(int key, int weight) {
        Map<Integer, Map<String, Integer>> connections = getConnections();
        if (connections.containsKey(key)) {
            System.out.println("Vertex already a neighbour");
            return false;
        }
        Map<String, Integer> connection = new HashMap<>();
        connection.put("weight", weight);
        connection.put("accessible", 1);
        connections.put(key, connection);
        return true;
    }

    /**
     * Adds a vertex key to map of neighbours, assumes that the key represents an existing vertex.
     * Assigns weight to the added vertex from weight parameter.
     * Assigns accessible status from accessible parameter.
     * @param key a vertex key.
     * @param weight an integer number to represent the weight of an edge.
     * @param accessible integer value for accessible status; 0 for not accessible 1 for accessible.
     * @return True if vertex was added as neighbour, false if already a neighbour.
     */
    public boolean addNeighbour(int key, int weight, int accessible) {
        Map<Integer, Map<String, Integer>> connections = getConnections();
        if (connections.containsKey(key)) {
            System.out.println("Vertex already a neighbour");
            return false;
        }
        Map<String, Integer> connection = new HashMap<>();
        connection.put("weight", weight);
        connection.put("accessible", accessible);
        connections.put(key, connection);
        return true;
    }
}
