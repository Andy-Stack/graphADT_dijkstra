import java.util.*;

public class Graph {

    private final Map<Integer, Vertex> vertices;
    private final String nl = System.lineSeparator();
    private int size;

    public Graph() {
        vertices = new HashMap<>();
        size = 0;
    }

    public int getSize() {
        return size;
    }

    public Set<Integer> getVertexKeys() {
        return vertices.keySet();
    }

    public Collection<Vertex> getVertices() {
        return vertices.values();
    }
    public Vertex getVertex(int key) {
        if (contains(key)) {
            return vertices.get(key);
        }
        return null;
    }

    /**
     * Adds a vertex to the graph with the provided key parameter.
     * @param key vertex key.
     * @return Either new vertex or existing vertex if key already exists.
     */
    public Vertex addVertex(int key) {
        if (!getVertexKeys().contains(key)) {
            Vertex newVertex = new Vertex(key);
            vertices.put(key, newVertex);
            size++;
            return newVertex;
        }
        else {
            System.out.println("Vertex with key '" + key + "' already exists");
            return getVertex(key);
        }
    }

    /**
     * @param key a vertex key.
     * @return Boolean true if vertex with key parameter exists, false otherwise.
     */
    public boolean contains(int key) {
        return vertices.containsKey(key);
    }

    /**
     * Removes a vertex from the graph.
     * @param key a vertex key.
     * @return Boolean true if vertex was removed, false if vertex was not in graph.
     */
    public boolean deleteVertex(int key) {
        if (contains(key)) {
            vertices.remove(key);
            return true;
        }
        return false;
    }

    /**
     * Deletes edge from vertex 'key1' to vertex 'key2' from graph.
     * Note that an edge between vertex 'key2' and vertex 'key1' is not deleted.
     * @param key1 a vertex key.
     * @param key2 a vertex key.
     * @return True if vertex 'key2' is connected to vertex 'key1' and edge is deleted, otherwise false.
     */
    public boolean deleteEdge(int key1, int key2) {
        if (contains(key1)) {
            return getVertex(key1).deleteEdge(key2);
        }
        return false;
    }

    /**
     * Adds an edge between vertex 'key1' and vertex 'key2. Vertices are created if they are not present in graph.
     * Note that an edge is not added between vertex 'key2' and vertex 'key1'.
     * @param key1 a vertex key.
     * @param key2 a vertex key.
     * @return Either new vertex or existing vertex if key already exists.
     */
    public boolean addEdge(int key1, int key2) {
        if (!contains(key1)) {
            addVertex(key1);
        }
        if (!contains(key2)) {
            addVertex(key2);
        }
        return getVertex(key1).addNeighbour(key2);
    }

    /**
     * Adds an edge between vertex 'key1' and vertex 'key2. Vertices are created if they are not present in graph.
     * New edge is assigned a weight from 'weight' parameter.
     * Note that an edge is not added between vertex 'key2' and vertex 'key1'.
     * @param key1 a vertex key.
     * @param key2 a vertex key.
     * @param weight integer value to represent edge weight.
     * @return Either new vertex or existing vertex if key already exists.
     */
    public boolean addEdge(int key1, int key2, int weight) {
        if (!contains(key1)) {
            addVertex(key1);
        }
        if (!contains(key2)) {
            addVertex(key2);
        }
        return getVertex(key1).addNeighbour(key2, weight);
    }

    /**
     * Adds an edge between vertex 'key1' and vertex 'key2. Vertices are created if they are not present in graph.
     * New edge is assigned a weight from 'weight' parameter and accessible status from 'accessible' parameter.
     * Note that an edge is not added between vertex 'key2' and vertex 'key1'.
     * @param key1 a vertex key.
     * @param key2 a vertex key.
     * @param weight integer value to represent edge weight.
     * @param accessible integer value for accessible status; 0 for not accessible 1 for accessible.
     * @return Either new vertex or existing vertex if key already exists.
     */
    public boolean addEdge(int key1, int key2, int weight, int accessible) {
        if (!contains(key1)) {
            addVertex(key1);
        }
        if (!contains(key2)) {
            addVertex(key2);
        }
        return getVertex(key1).addNeighbour(key2, weight, accessible);
    }

    /**
     * Implementation of Dijkstra's algorithm.
     * Method will print all vertices connected to source vertex.
     * Smallest weight from source vertex will also be printed for all vertices.
     * @param sourceKey a vertex key.
     */
    public void dijkstra(int sourceKey) {
        if (!getVertexKeys().contains(sourceKey)) {
            System.out.println("Invalid source: Vertex key not found" + nl);
            return;
        }
        dijkstraHelper(sourceKey, null);
        System.out.println("The following vertices are accessible from the source:");
        for (Vertex vertex : getVertices()) {
            if (vertex.getWeightFromSource() != Integer.MAX_VALUE) {
                System.out.println("Vertex: " + vertex.getKey() + " Weight from source: " + vertex.getWeightFromSource());
            }
        }
        System.out.println("Vertices not shown are either inaccessible or not connected" + nl);
    }

    /**
     * Implementation of Dijkstra's algorithm.
     * Method will print all vertices that form the path of least weight from source to destination vertex.
     * Total weight of path is also printed.
     * @param sourceKey a vertex key.
     * @param destinationKey a vertex key.
     */
    public void dijkstra(int sourceKey, int destinationKey) {
        if (!getVertexKeys().contains(sourceKey) && !getVertexKeys().contains(destinationKey)) {
            System.out.println("Invalid source or destination: Vertex key(s) not found" + nl);
            return;
        }
        dijkstraHelper(sourceKey, destinationKey);
        Vertex current = getVertex(destinationKey);
        if (current.getWeightFromSource() == Integer.MAX_VALUE) {
            System.out.println("Unable to reach destination from source vertex" + nl);
        } else {
            List<Integer> path = new ArrayList<>();
            while (current.getKey() != sourceKey) {
                Map<Integer, Map<String, Integer>> neighbours = current.getConnections();
                for (int neighbourKey : neighbours.keySet()) {
                    Vertex neighbour = getVertex(neighbourKey);
                    if (neighbour.getWeightFromSource() + neighbour.getConnections()
                            .get(current.getKey()).get("weight") == current.getWeightFromSource()) {
                        path.add(current.getKey());
                        current = neighbour;
                        break;
                    }
                }
            }
            path.add(sourceKey);
            Collections.reverse(path);
            System.out.println("Shortest path from source to destination:");
            System.out.println("Path: " + path + " Total weight: " + getVertex(destinationKey).getWeightFromSource() + nl);
        }
    }
    
    private void dijkstraHelper(int sourceKey, Integer destinationKey) {
        prepareGraph(sourceKey);
        PriorityQueue<List<Integer>> pQueue = buildPQueue(sourceKey, getVertexKeys());

        while (!pQueue.isEmpty()) {
            Vertex current = getVertex(pQueue.poll().get(0));
            if (destinationKey != null && current.getKey() == destinationKey) {
                return;
            }
            Map<Integer, Map<String, Integer>> neighbours = current.getConnections();
            for (int neighbour : neighbours.keySet()) {
                if (neighbours.get(neighbour).get("accessible") == 1) {
                    int oldWeight = getVertex(neighbour).getWeightFromSource();
                    int newWeight = current.getWeightFromSource() + neighbours.get(neighbour).get("weight");
                    if (newWeight < oldWeight) {
                        getVertex(neighbour).setWeightFromSource(newWeight);
                        updatePQueue(pQueue, neighbour, oldWeight, newWeight);
                    }
                }
            }
        }
    }

    private void prepareGraph(int sourceKey) {
        for (Vertex vertex : getVertices()) {
            vertex.setWeightFromSource(Integer.MAX_VALUE);
        }
        getVertex(sourceKey).setWeightFromSource(0);
    }

    private PriorityQueue<List<Integer>> buildPQueue(int sourceKey, Set<Integer> vertices) {
        PriorityQueue<List<Integer>> pQueue = new PriorityQueue<>(getSize(), new SortByWeight());
        for (int key : vertices) {
            List<Integer> tmp = new ArrayList<>();
            tmp.add(key);
            tmp.add(key == sourceKey ? 0 : Integer.MAX_VALUE);
            pQueue.add(tmp);
        }
        return pQueue;
    }

    private void updatePQueue(PriorityQueue<List<Integer>> pQueue, int vertex, int oldWeight, int newWeight) {
        List<Integer> update = new ArrayList<>();
        update.add(vertex);
        update.add(oldWeight);
        pQueue.remove(update);
        update.remove(1);
        update.add(newWeight);
        pQueue.add(update);
    }
}