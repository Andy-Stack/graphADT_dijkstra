/**
 * Comparator used by priority queue in Graph Class
 */
import java.util.Comparator;
import java.util.List;

public class SortByWeight implements Comparator<List<Integer>> {
    /**
     * Compares weight of each supplied vertex (weight is located at index 1 in list)
     * @param vert1 weight of vertex to compare
     * @param vert2 weight of vertex being compared
     * @return comparator int value to define order
     */
    public int compare(List<Integer> vert1, List<Integer> vert2){
        return vert1.get(1) - vert2.get(1);
    }
}
